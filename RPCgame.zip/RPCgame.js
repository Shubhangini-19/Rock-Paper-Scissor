let userscore=0;
let compscore=0;

const choices=document.querySelectorAll(".choice");
const msg=document.querySelector("#msg");
const userscores=document.querySelector("#user-score");
const compscores=document.querySelector("#comp-score");
const generatecomputerchoice=()=>{
    const options=["rocks","paper","scissors"];
    const randind =Math.floor(Math.random()*3);
    return options[randind];
};
const drawgame=(userwin)=>{
    
    msg.innerText="game was draw, both are same";
    msg.style.backgroundColor="orange";
};
const showwinner=(userwin,userchoice,compchoice)=>{
    if(userwin){
        userscore++;
        userscores.innerText=userscore;
        msg.innerText=`you win! ${userchoice} beats ${compchoice}`;
        msg.style.backgroundColor="green";
    }
    else{
        compscore++;
        compscores.innerText=compscore;
        msg.innerText=`you lose ${compchoice} beats ${userchoice}`;
        msg.style.backgroundColor="red";
    }
};
const playgame=(userchoice)=>{
console.log("user choice=",userchoice);
const compchoice=generatecomputerchoice();
console.log("comp choice=",compchoice);
if(userchoice===compchoice){
    drawgame();
}
else{
    let userwin=true;
    if(userchoice==="rock"){
      userwin =  compchoice==="paper"? false:true;
    }
    else if(userchoice==="paper"){
        userwin= compchoice==="scissors"? false: true;
    }
    else{
        userwin= compchoice==="rock"? false: true;
    }
showwinner(userwin,userchoice,compchoice);
}
};
choices.forEach((choice)=>{
    
    choice.addEventListener("click",()=>{
        const userchoice=choice.getAttribute("id")
       
        playgame(userchoice);
    });
});